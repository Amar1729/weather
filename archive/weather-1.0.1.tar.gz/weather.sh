#!/usr/bin/env sh

curl "wttr.in/$1"
